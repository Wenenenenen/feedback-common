# 单元盒约束等值面约定
输入JSON含dims、origin、spacing、signs、edges。dims是各轴2到33个节点，origin为节点000的世界坐标，spacing为正物理间距，范围1e-4到100，origin绝对值不超过10000。signs为x最快、再y、再z的扁平数组，长度为dims乘积，只允许-1和1，-1表示实体内。边交点已由前序采样完成，本题不估计梯度。
edges的每项为axis、node、t、normal。axis是x或y或z，node是边上坐标较小的端点的整数三元组，另一端沿axis加1。位置h=origin+spacing*(node+t*axis_unit)，严格要求0<t<1。normal是指向符号增大方向的非零世界法线，长度可不为1，计算前归一化。每条异号边必须恰有一条记录，同号边不得有记录；缺失、重复、越界、零法线及非有限数值均报出边或字段位置。法线方向由输入保证，不按正轴强行翻转。
一个正负混合单元只生成一个共享顶点。收集其12条边的所有交点与单位法线，c是这些交点的平均。顶点是闭单元盒内F(x)=sum_e (n_e dot (x-h_e))²+lambda*||x-c||²的全局最小点。lambda默认0.001，可调1e-6到1。必须真正求盒约束最小值，不能把无约束解逐轴夹住，也不能直接用c替代。正则项确保退化平面输入仍有唯一解。
单元编号按其较小角节点的z、y、x升序分配，只给混合单元编号。每条异号原网格边若有完整4个相邻单元，就连接这4个共享顶点成四边形。缺少相邻单元时跳过该边，保留边界开口并计数，不生成封口，不焊点。
围绕正x边的单元顺序为(i,j-1,k-1)、(i,j,k-1)、(i,j,k)、(i,j-1,k)；正y边为(i-1,j,k-1)、(i-1,j,k)、(i,j,k)、(i,j,k-1)；正z边为(i-1,j-1,k)、(i,j-1,k)、(i,j,k)、(i-1,j,k)。这些顺序法向朝正轴。边起点负、终点正时采用该顺序，否则保留第一个点并倒转其余顺序。四边形记A、B、C、D，固定拆成ABC与ACD。处理顺序为axis的x、y、z，再按node的z、y、x升序。
界面提供旋转缩放的三维线框与网格切层视图，切层可选轴和单元层号；输入单元坐标或点选时联动显示单元盒、交点、法线、无约束解、最终解、各平面残差及总目标。可编辑共享边的t和法线，更新所有受影响单元和面；可调lambda和恢复导入值。
导出OBJ三角网格和诊断JSON。后者含vertices、triangles、cells及boundary_crossings、boundary_edges、nonmanifold_edges；cells与vertices同序，每项含cell、position、unconstrained、active_axes、data_error、objective。active_axes逐轴写lower、free或upper。boundary_crossings是缺少4个相邻单元的异号边数；另两项按三角形无向边的面使用次数等于1和大于2计数。此单顶点规则不保证任意符号图形均为流形，必须如实报告统计。全部同号时正常导出空网格。
坐标及目标误差不超过1e-6*max(1,参考量绝对值)，所有输出有限。expected.json含拓扑计数、解析探针和错误案例说明；skew-cell特意让无约束解越界，简单夹取不满足最优性。
